# sendsms-opencart4
Modul SendSMS pentru Opencart 4.x
Modul compatibil cu OpenCart versiune 4.x pentru integrarea cu sendSMS.ro https://www.sendsms.ro/
